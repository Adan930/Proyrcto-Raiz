#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <cstring>
#include <cmath>
#include <vector>
#include <string>
#include <fstream>
#include <sstream>
#include "juego_traduccion.h"

using namespace std;

struct Palabra {
    string nahuatl;
    string espanol;
};

static void limpiarBufferTraduccion() {
    int c;
    while ((c = getchar()) != '\n' && c != EOF);
}

// Funci�n para cargar palabras desde archivo
vector<Palabra> cargarPalabrasDesdeArchivo(const char* nombreArchivo) {
    vector<Palabra> palabras;
    ifstream archivo(nombreArchivo);
    
    if (!archivo.is_open()) {
        printf("Error: No se pudo abrir el archivo %s\n", nombreArchivo);
        return palabras;
    }
    
    string linea;
    while (getline(archivo, linea)) {
        stringstream ss(linea);
        string nahuatl, espanol;
        
        if (getline(ss, nahuatl, ',') && getline(ss, espanol)) {
            Palabra p;
            p.nahuatl = nahuatl;
            p.espanol = espanol;
            palabras.push_back(p);
        }
    }
    
    archivo.close();
    printf("Cargadas %zu palabras desde %s\n", palabras.size(), nombreArchivo);
    return palabras;
}

// ---------------- MINIJUEGO: TRADUCCI�N R�PIDA CON DIFICULTAD ---------------- //

int jugarTraduccionRapida() {
    // Cargar palabras desde archivos
    vector<Palabra> palabrasBasico = cargarPalabrasDesdeArchivo("basico.txt");
    vector<Palabra> palabrasAvanzado = cargarPalabrasDesdeArchivo("avanzado.txt");
    
    // Si no se pudieron cargar los archivos, usar valores por defecto
    if (palabrasBasico.empty()) {
        printf("Usando palabras b�sicas por defecto...\n");
        palabrasBasico = {
            {"atl", "agua"}, {"xochitl", "flor"}, {"calli", "casa"},
            {"tlalli", "tierra"}, {"tepetl", "cerro"}, {"metztli", "luna"},
            {"citlalli", "estrella"}, {"cualli", "bueno"}, {"tletl", "fuego"},
            {"tlakatl", "hombre"}, {"coyotl", "coyote"}, {"tochtli", "conejo"},
            {"coatl", "serpiente"}, {"cuauhtli", "aguila"}, {"mazatl", "venado"}
        };
    }
    
    if (palabrasAvanzado.empty()) {
        printf("Usando palabras avanzadas por defecto...\n");
        palabrasAvanzado = {
            {"yolotl", "corazon"}, {"ichtli", "fibra"}, {"chichi", "perro"},
            {"ehecatl", "viento"}, {"xihuitl", "a�o/hierba"}, {"tonatiuh", "sol"},
            {"tlazohcamati", "gracias"}, {"nimitztlazohtla", "te amo"},
            {"tlahueliloc", "enojado"}, {"necuametl", "amigo"}, {"ahuacatl", "aguacate"},
            {"chocolatl", "chocolate"}, {"tomati", "tomate"}, {"cacahuatl", "cacahuate"},
            {"xocoatl", "serpiente de fuego"}, {"miquiztli", "muerte"},
            {"yohualli", "noche"}, {"tlapalli", "color"}, {"zoquitl", "lodo"},
            {"nextli", "ceniza"}
        };
    }

    // Selecci�n de dificultad
    printf("\n=== SELECCION DE DIFICULTAD ===\n");
    printf("1. BASICO (Palabras simples)\n");
    printf("2. AVANZADO (Palabras complejas)\n");
    printf("Elige la dificultad (1-2): ");
    
    int dificultad;
    if (scanf("%d", &dificultad) != 1 || (dificultad != 1 && dificultad != 2)) {
        printf("Opcion invalida. Usando nivel BASICO por defecto.\n");
        dificultad = 1;
    }
    limpiarBufferTraduccion();

    // Configuraci�n seg�n dificultad
    vector<Palabra> palabras;
    int preguntas;
    double tiempoLimite;
    int puntosBase;
    int multiplicador;
    int vidas = 3;

    if (dificultad == 1) {
        palabras = palabrasBasico;
        preguntas = 8;
        tiempoLimite = 15.0;
        puntosBase = 80;
        multiplicador = 15;
        printf("\n=== NIVEL BASICO ===\n");
        printf("Tiempo por pregunta: %.0f segundos\n", tiempoLimite);
    } else {
        palabras = palabrasAvanzado;
        preguntas = 10;
        tiempoLimite = 10.0;
        puntosBase = 120;
        multiplicador = 25;
        printf("\n=== NIVEL AVANZADO ===\n");
        printf("Tiempo por pregunta: %.0f segundos\n", tiempoLimite);
    }

    int N = palabras.size();
    if (preguntas > N) preguntas = N;

    vector<int> indices(N);
    for (int i = 0; i < N; i++) indices[i] = i;

    // Mezclar preguntas
    for (int i = N - 1; i > 0; i--) {
        int j = rand() % (i + 1);
        swap(indices[i], indices[j]);
    }

    int totalAciertos = 0;
    int totalFallos = 0;
    double sumaTiempos = 0.0;
    int puntosTotales = 0;

    printf("Vidas: ?? ?? ??\n");
    printf("Responde %d preguntas. Maximo %d errores.\n", preguntas, vidas);
    printf("Premio: %d puntos base + bonus por rapidez (x%d).\n\n", puntosBase, multiplicador);

    for (int q = 0; q < preguntas && vidas > 0; q++) {
        printf("\n--- Pregunta %d/%d ---\n", q + 1, preguntas);
        printf("Vidas restantes: ");
        for (int i = 0; i < vidas; i++) printf("+ ");
        for (int i = vidas; i < 3; i++) printf("- ");
        printf("\n");

        int idxCorrecto = indices[q];
        vector<int> opcionesIdx(4);
        opcionesIdx[0] = idxCorrecto;
        int llenadas = 1;
        
        // Seleccionar opciones incorrectas �nicas
        while (llenadas < 4) {
            int cand = rand() % N;
            bool repetido = false;
            for (int k = 0; k < llenadas; k++) {
                if (opcionesIdx[k] == cand) {
                    repetido = true;
                    break;
                }
            }
            if (!repetido) opcionesIdx[llenadas++] = cand;
        }

        // Mezclar opciones
        for (int i = 3; i > 0; i--) {
            int j = rand() % (i + 1);
            swap(opcionesIdx[i], opcionesIdx[j]);
        }

        printf("�Que significa '%s' en espanol?\n", palabras[idxCorrecto].nahuatl.c_str());
        for (int i = 0; i < 4; i++) {
            printf("  %d) %s\n", i + 1, palabras[opcionesIdx[i]].espanol.c_str());
        }

        printf("Tu respuesta (1-4): ");
        fflush(stdout);
        
        clock_t inicio = clock();
        int respuesta = 0;
        
        if(scanf("%d", &respuesta) != 1) {
            respuesta = 0;
        }
        limpiarBufferTraduccion();
        
        clock_t fin = clock();

        double tiempo = (double)(fin - inicio) / CLOCKS_PER_SEC;
        sumaTiempos += tiempo;

        if (tiempo > tiempoLimite) {
            printf(" �TIEMPO AGOTADO! (%.1f s) Pierdes una vida.\n", tiempo);
            vidas--;
            totalFallos++;
            if (vidas > 0) {
                printf("La respuesta correcta era: '%s'\n", palabras[idxCorrecto].espanol.c_str());
            }
        } else if (respuesta < 1 || respuesta > 4) {
            printf(" Opci�n invalida. Pierdes una vida.\n");
            vidas--;
            totalFallos++;
            if (vidas > 0) {
                printf("La respuesta correcta era: '%s'\n", palabras[idxCorrecto].espanol.c_str());
            }
        } else {
            int elegidoIdx = opcionesIdx[respuesta - 1];
            if (elegidoIdx == idxCorrecto) {
                int bonus = (int)fmax(0, (tiempoLimite - tiempo) * multiplicador);
                int puntos = puntosBase + bonus;
                puntosTotales += puntos;
                totalAciertos++;
                
                if (tiempo < tiempoLimite * 0.3) {
                    printf("?? �Excelente! +%d puntos (bonus: %d)\n", puntosBase, bonus);
                } else if (tiempo < tiempoLimite * 0.6) {
                    printf("? �Bien hecho! +%d puntos (bonus: %d)\n", puntosBase, bonus);
                } else {
                    printf("?? Correcto. +%d puntos (bonus: %d)\n", puntosBase, bonus);
                }
                printf("Tiempo usado: %.1f s\n", tiempo);
            } else {
                printf(" Incorrecto. Era '%s'.\n", palabras[idxCorrecto].espanol.c_str());
                if (dificultad == 2) {
                    printf("   Significado: %s\n", palabras[idxCorrecto].espanol.c_str());
                }
                vidas--;
                totalFallos++;
                if (vidas > 0) {
                    printf("Pierdes una vida.\n");
                }
            }
        }

        if (vidas <= 0) {
            printf("\n?? �GAME OVER! Te has quedado sin vidas.\n");
            break;
        }
    }

    // Mostrar resultados finales (el resto del c�digo permanece igual)
    printf("\n=== RESULTADOS FINALES ===\n");
    
    if (vidas > 0) {
        printf(" �FELICIDADES! Completaste el nivel.\n");
    } else {
        printf(" Juego terminado por falta de vidas.\n");
    }
    
    printf(" Aciertos: %d/%d\n", totalAciertos, (vidas > 0 ? preguntas : (totalAciertos + totalFallos)));
    printf("Fallos: %d\n", totalFallos);
    printf("  Vidas restantes: %d\n", vidas);
    
    if (totalAciertos + totalFallos > 0) {
        double promedio = sumaTiempos / (totalAciertos + totalFallos);
        printf("  Tiempo promedio: %.2f s\n", promedio);
    }
    
    printf(" Puntaje base: %d\n", puntosTotales);
    
    if (vidas > 0) {
        double porcentajeAciertos = (double)totalAciertos / preguntas * 100;
        if (porcentajeAciertos == 100) {
            int bonusPerfecto = (dificultad == 1) ? 200 : 500;
            puntosTotales += bonusPerfecto;
            printf(" �PERFECTO! Bonus +%d puntos\n", bonusPerfecto);
        } else if (porcentajeAciertos >= 80) {
            int bonusExcelente = (dificultad == 1) ? 100 : 250;
            puntosTotales += bonusExcelente;
            printf(" �EXCELENTE! Bonus +%d puntos\n", bonusExcelente);
        }
        
        if (vidas == 3) {
            int bonusVidas = (dificultad == 1) ? 150 : 300;
            puntosTotales += bonusVidas;
            printf(" Bonus vidas completas +%d puntos\n", bonusVidas);
        } else if (vidas == 2) {
            int bonusVidas = (dificultad == 1) ? 75 : 150;
            puntosTotales += bonusVidas;
            printf(" Bonus vidas restantes +%d puntos\n", bonusVidas);
        }
    }
    
    printf(" PUNTAGE FINAL: %d\n", puntosTotales);
    printf("===========================\n");

    return puntosTotales;
}
