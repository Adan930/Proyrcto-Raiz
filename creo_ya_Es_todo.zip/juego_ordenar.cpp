#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <windows.h>
#include "juego_ordenar.h"

// === BANCO DE FRASES ===
// Usar const char* para indicar que son cadenas constantes
const char* nahuatl_correctas[] = {
    // BASICO
    "Nimitztlazohtla", "Nimitzitta", "Tonal mitlalia", "Atl chkaloki", "Tlakatl motlaloa",
    // AVANZADO
    "Nehuatl nicuica cuicatl", "Piltontli tzajtzia", "Kokoneh motlaliah", "Nikuika kuikatl", "Tlatskanilistli mochipa"
};
const char* nahuatl_desordenadas[] = {
    "tla zo mi tz Ni ht", "ti mi nit tza", "to mi na l tal", "at ki chl la o", "la mo ta tl kl",
    "cu ne atl hu ca nic", "tz pil ia li ton tz", "ko ne mo ko la h tl", "nik ui ka ka ti", "mo li chi ts pa ca"
};

const char* xiu_correctas[] = {
    // BASICO
    "Gi madi", "Di nana", "Di ra nthoki", "Ra madi hno", "Ra madi mahnu",
    // AVANZADO
    "Di pizza gi", "Befi ra hnaki", "Feni ra ngu", "Ra yohi ra ntho", "Ra ngu ra mote"
};
const char* xiu_desordenadas[] = {
    "ma gi di", "di na na", "di to nk ra hi", "hno ma ra di", "mah ra nu di",
    "za gi di piz", "fi ki ra hna", "ngu ra fe ni", "ra ntho yo ra hi", "ra mo ngu te ra"
};

// === ESTILO GTOXIC ===
static void gotoxy(int x, int y) {
    COORD c; c.X = x; c.Y = y;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), c);
}
static void setColor(int color) {
    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), color);
}
static void centrar(const char* txt, int y, int color) {
    CONSOLE_SCREEN_BUFFER_INFO csbi;
    GetConsoleScreenBufferInfo(GetStdHandle(STD_OUTPUT_HANDLE), &csbi);
    int ancho = csbi.srWindow.Right - csbi.srWindow.Left + 1;
    int x = (ancho - strlen(txt)) / 2;
    setColor(color);
    gotoxy(x, y); printf("%s", txt);
    setColor(7);
}
static void limpiarBuffer() {
    int c; while ((c = getchar()) != '\n' && c != EOF);
}

// === FUNCION PRINCIPAL ===
int jugarOrdenarFrases() {
    int idioma = 0;
    int nivel = 0;
    int vidas = 3;
    int puntos = 0;

    // --- MENU IDIOMA ---
    system("cls");
    centrar("=== ORDENA LA FRASE ===", 3, 11);
    centrar("Selecciona la Lengua:", 5, 15);
    centrar("1. Nahuatl", 7, 10);
    centrar("2. Xi'u (Otomi)", 8, 14);
    
    gotoxy(35, 10); printf("Opcion: ");
    scanf("%d", &idioma);
    limpiarBuffer();

    // --- MENU NIVEL ---
    system("cls");
    centrar("=== DIFICULTAD ===", 3, 11);
    centrar("1. Basico (Frases Cortas)", 6, 10);
    centrar("2. Avanzado (Frases Largas)", 7, 12);
    
    gotoxy(35, 9); printf("Opcion: ");
    scanf("%d", &nivel);
    limpiarBuffer();

    // Punteros para seleccionar el banco de preguntas correcto
    const char** correctas;  // Agregar const aqu� tambi�n
    const char** desordenadas;  // Agregar const aqu� tambi�n

    if (idioma == 1) { // Nahuatl
        correctas = nahuatl_correctas;
        desordenadas = nahuatl_desordenadas;
    } else { // Xi'u
        correctas = xiu_correctas;
        desordenadas = xiu_desordenadas;
    }

    // Configurar rango (0-4 B�sico, 5-9 Avanzado)
    int inicio = (nivel == 2) ? 5 : 0;
    int fin = (nivel == 2) ? 10 : 5;
    int ptsPorAcierto = (nivel == 2) ? 30 : 15;

    // --- BUCLE DE JUEGO ---
    for (int i = inicio; i < fin; i++) {
        if (vidas <= 0) break;

        system("cls");
        // HUD
        setColor(14);
        printf("\n   VIDAS: %d   |   PUNTOS: %d\n", vidas, puntos);
        setColor(7);
        printf("   --------------------------------\n");

        centrar("Ordena las silabas/palabras:", 5, 11);
        
        // Mostrar frase desordenada
        centrar(desordenadas[i], 7, 15); // Blanco brillante

        centrar("Escribe la respuesta correcta:", 10, 7);
        gotoxy(20, 12); 
        printf("> ");

        char respuesta[200];
        fgets(respuesta, sizeof(respuesta), stdin);
        // Eliminar salto de l�nea
        respuesta[strcspn(respuesta, "\n")] = 0;

        // Comparaci�n (simple, sensible a may�sculas/espacios exactos)
        if (strcmp(respuesta, correctas[i]) == 0) {
            centrar("EXCELENTE!", 14, 10);
            puntos += ptsPorAcierto;
        } else {
            centrar("INCORRECTO...", 14, 12);
            vidas--;
            Beep(200, 300);
            
            // Mostrar correcci�n
            char sol[200];
            sprintf(sol, "Correcto: %s", correctas[i]);
            centrar(sol, 16, 8); // Gris
        }
        Sleep(2000);
    }

    // --- RESULTADO ---
    system("cls");
    if (vidas > 0) {
        centrar("�FELICIDADES!", 10, 10);
        char final[50]; sprintf(final, "Puntaje Total: %d", puntos);
        centrar(final, 12, 14);
    } else {
        centrar("GAME OVER", 10, 12);
        centrar("Intentalo de nuevo.", 12, 7);
        puntos = 0;
    }
    Sleep(2000);
    return puntos;
}
