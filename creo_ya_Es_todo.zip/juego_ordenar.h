#ifndef JUEGO_ORDENAR_H
#define JUEGO_ORDENAR_H

// El traductor C++ a C
#ifdef __cplusplus
extern "C" {
#endif

// El "anuncio" de tu juego. Devuelve los puntos ganados.
int jugarOrdenarFrases();

#ifdef __cplusplus
}
#endif

#endif // JUEGO_ORDENAR_H