#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <windows.h>
#include "juego_combate.h"

// --- FUNCIONES VISUALES ---
static void gotoxy(int x, int y) {
    COORD coord; coord.X = x; coord.Y = y;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
}
static void setColor(int color) {
    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), color);
}
static void centrar(const char* txt, int y, int color) {
    CONSOLE_SCREEN_BUFFER_INFO csbi;
    GetConsoleScreenBufferInfo(GetStdHandle(STD_OUTPUT_HANDLE), &csbi);
    int ancho = csbi.srWindow.Right - csbi.srWindow.Left + 1;
    int x = (ancho - strlen(txt)) / 2;
    setColor(color);
    gotoxy(x, y); printf("%s", txt);
    setColor(7); 
}
static void limpiarBuffer() {
    int c; while ((c = getchar()) != '\n' && c != EOF);
}

// --- ESTRUCTURAS ---
typedef struct { char esp[30]; char ind[30]; int danio; } Hechizo;
typedef struct { char nombre[30]; int vida; int maxVida; int ataque; } Enemigo;
typedef struct { char nick[20]; int vida; int maxVida; } JugadorBatalla;

static int mi_strcasecmp(const char *s1, const char *s2) {
    while (*s1 && *s2) {
        char c1 = *s1, c2 = *s2;
        if (c1 >= 'A' && c1 <= 'Z') c1 += 32;
        if (c2 >= 'A' && c2 <= 'Z') c2 += 32;
        if (c1 != c2) return c1 - c2;
        s1++; s2++;
    }
    return *s1 - *s2;
}

// --- LOGICA PRINCIPAL ---
int iniciarCombate(const char *nicknameJugador) {
    // 1. SELECCION DE NIVEL (DIFICULTAD)
    int dificultad = 1;
    system("cls");
    centrar("=== COMBATE NAHUATL ===", 3, 11);
    centrar("1. Nivel Basico (Espiritu Debil)", 6, 10);
    centrar("2. Nivel Avanzado (Demonio Antiguo)", 7, 12);
    centrar("Elige dificultad: ", 9, 7);
    scanf("%d", &dificultad);
    limpiarBuffer();

    // Configurar Enemigo segun nivel
    Enemigo enemigo;
    if (dificultad == 2) {
        strcpy(enemigo.nombre, "Tlacatecolotl (Demonio)");
        enemigo.maxVida = 150; // Mas vida
        enemigo.ataque = 25;   // Pega mas fuerte
    } else {
        strcpy(enemigo.nombre, "Espiritu del Bosque");
        enemigo.maxVida = 80;
        enemigo.ataque = 10;
    }
    enemigo.vida = enemigo.maxVida;

    JugadorBatalla jugador;
    strcpy(jugador.nick, nicknameJugador);
    jugador.maxVida = 100;
    jugador.vida = 100;

    Hechizo grimoire[3] = {
        {"Fuego", "Tletl", 35},
        {"Agua", "Atl", 25},
        {"Viento", "Ehecatl", 20}
    };

    // 2. BUCLE DE PELEA (Solo termina si alguien muere)
    while (jugador.vida > 0 && enemigo.vida > 0) {
        system("cls");
        
        // HUD
        setColor(11);
        printf("\n  %s (HP: %d/%d)  VS  %s (HP: %d/%d)\n", 
               jugador.nick, jugador.vida, jugador.maxVida, 
               enemigo.nombre, enemigo.vida, enemigo.maxVida);
        setColor(7);
        printf("  --------------------------------------------------\n\n");

        // Menu Hechizos
        printf("  TU TURNO - Elige un hechizo:\n");
        for(int i=0; i<3; i++) {
            printf("  %d. %s (Dano: %d)\n", i+1, grimoire[i].esp, grimoire[i].danio);
        }
        printf("\n  Opcion > ");
        
        int op;
        scanf("%d", &op);
        limpiarBuffer();

        if (op < 1 || op > 3) {
            printf("\n  Perdiste el turno por distraccion...\n");
        } else {
            int idx = op - 1;
            printf("\n  Escribe '%s' en Nahuatl: ", grimoire[idx].esp);
            char respuesta[30];
            fgets(respuesta, 30, stdin);
            respuesta[strcspn(respuesta, "\n")] = 0;

            if (mi_strcasecmp(respuesta, grimoire[idx].ind) == 0) {
                setColor(10); // Verde
                printf("\n  CORRECTO! %s impacta al enemigo!\n", grimoire[idx].ind);
                enemigo.vida -= grimoire[idx].danio;
            } else {
                setColor(12); // Rojo
                printf("\n  FALLASTE. La palabra era '%s'. No haces danio.\n", grimoire[idx].ind);
                // NOTA: Ya no restamos vidas, simplemente perdiste el turno de atacar
            }
        }
        setColor(7);

        if (enemigo.vida <= 0) break; // Ganaste

        Sleep(1000);
        // Turno del Enemigo
        printf("\n  --- Turno de %s ---\n", enemigo.nombre);
        printf("  Te ataca y causa %d de danio!\n", enemigo.ataque);
        jugador.vida -= enemigo.ataque;
        
        printf("\n  Presiona Enter...");
        getchar();
    }

    // 3. RESULTADOS
    system("cls");
    if (enemigo.vida <= 0) {
        centrar("VICTORIA MAGISTRAL", 10, 10);
        char msg[100]; sprintf(msg, "Derrotaste a %s", enemigo.nombre);
        centrar(msg, 12, 15);
        Sleep(2000);
        return (dificultad == 2) ? 100 : 50; // XP Ganada
    } else {
        setColor(12);
        centrar("DERROTA...", 10, 12);
        centrar("Te has quedado sin puntos de vida.", 12, 14);
        Sleep(2000);
        return 0;
    }
}
