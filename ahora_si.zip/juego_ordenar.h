#ifndef JUEGO_ORDENAR_H
#define JUEGO_ORDENAR_H

// Prototipo de la funci�n principal
int jugarOrdenarFrases();

#endif
