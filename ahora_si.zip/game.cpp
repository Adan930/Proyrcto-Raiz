#include "game.h"
#include <iostream>
#include <string>
#include <limits> 
#include <fstream>
#include <windows.h> // Para gotoxy y colores

#include "juego_combate.h"
#include "juego_traduccion.h"
#include "juego_adivinanza.h"
#include "juego_ordenar.h"

using namespace std;



// ======================= GOTOXY Y COLORES ===========================
void gotoxy(int x, int y) {
    COORD c;
    c.X = x;
    c.Y = y;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), c);
}

void setColor(int color) {
    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), color);
}

int anchoPantalla = 80;

void printCentrado(const string& txt, int y, int color = 15) {
    int x = (anchoPantalla - txt.size()) / 2;
    setColor(color);
    gotoxy(x, y);
    cout << txt;
    setColor(15);
}

// ======================= SISTEMA DE ARCHIVOS ===========================

const string ARCHIVO_PERSONAJES = "personajes.txt";

bool personajeExiste(const string& nombre) {
    ifstream archivo(ARCHIVO_PERSONAJES);
    if (!archivo.is_open()) {
        return false;
    }
    
    string linea;
    while (getline(archivo, linea)) {
        if (linea.find("Nombre: " + nombre) != string::npos) {
            archivo.close();
            return true;
        }
    }
    
    archivo.close();
    return false;
}

void guardarPersonaje(const Personaje* pj) {
    ofstream archivo(ARCHIVO_PERSONAJES, ios::app); // Modo append
    
    if (archivo.is_open()) {
        archivo << "=== PERSONAJE ===" << endl;
        archivo << "Nombre: " << pj->nombre << endl;
        archivo << "Nivel: " << pj->nivel << endl;
        archivo << "XP: " << pj->xp << endl;
        archivo << "XP_Necesario: " << pj->xpNecesario << endl;
        archivo << "Palabras_Aprendidas: " << pj->palabrasAprendidas << endl;
        archivo << "Progreso: ";
        for (int i = 0; i < 4; i++) {
            archivo << pj->progreso[i];
            if (i < 3) archivo << ",";
        }
        archivo << endl;
        archivo << "=== FIN PERSONAJE ===" << endl << endl;
        archivo.close();
        
        printCentrado("Perfil guardado exitosamente en " + ARCHIVO_PERSONAJES, 20, 10);
    } else {
        printCentrado("Error: No se pudo guardar el personaje", 20, 12);
    }
}

bool cargarPersonaje(Personaje* pj, const string& nombre) {
    ifstream archivo(ARCHIVO_PERSONAJES);
    if (!archivo.is_open()) {
        return false;
    }
    
    string linea;
    bool encontrado = false;
    
    while (getline(archivo, linea)) {
        if (linea.find("Nombre: " + nombre) != string::npos) {
            encontrado = true;
            
            // Leer los datos del personaje
            while (getline(archivo, linea) && linea != "=== FIN PERSONAJE ===") {
                if (linea.find("Nivel: ") != string::npos) {
                    pj->nivel = stoi(linea.substr(7));
                } else if (linea.find("XP: ") != string::npos) {
                    pj->xp = stoi(linea.substr(4));
                } else if (linea.find("XP_Necesario: ") != string::npos) {
                    pj->xpNecesario = stoi(linea.substr(14));
                } else if (linea.find("Palabras_Aprendidas: ") != string::npos) {
                    pj->palabrasAprendidas = stoi(linea.substr(21));
                } else if (linea.find("Progreso: ") != string::npos) {
                    string progresoStr = linea.substr(10);
                    size_t pos = 0;
                    int i = 0;
                    while ((pos = progresoStr.find(',')) != string::npos && i < 4) {
                        pj->progreso[i] = stoi(progresoStr.substr(0, pos));
                        progresoStr.erase(0, pos + 1);
                        i++;
                    }
                    if (i < 4) {
                        pj->progreso[i] = stoi(progresoStr);
                    }
                }
            }
            break;
        }
    }
    
    archivo.close();
    return encontrado;
}

void mostrarPersonajesGuardados() {
    ifstream archivo(ARCHIVO_PERSONAJES);
    if (!archivo.is_open()) {
        printCentrado("No hay personajes guardados", 15, 12);
        return;
    }
    
    system("cls");
    printCentrado("=== PERSONAJES GUARDADOS ===", 3, 11);
    
    string linea;
    int y = 5;
    bool hayPersonajes = false;
    
    while (getline(archivo, linea)) {
        if (linea.find("Nombre: ") != string::npos) {
            gotoxy(25, y);
            cout << linea;
            y++;
            hayPersonajes = true;
        }
    }
    
    if (!hayPersonajes) {
        printCentrado("No se encontraron personajes guardados", 10, 12);
    }
    
    archivo.close();
}

// ======================= FUNCIONES ORIGINALES ===========================

void limpiarBufferCin() {
    cin.ignore(numeric_limits<streamsize>::max(), '\n');
}

void pausarConsola() {
    cout << "\nPresiona Enter para continuar...";
    limpiarBufferCin();
    getchar();
}

Juego* crearListaJuegos() {
    Juego* j1 = new Juego{"Combate ", 0, NULL};
    Juego* j2 = new Juego{"Traduccion Rapida ", 0, NULL};
    Juego* j3 = new Juego{"Adivinanza", 0, NULL};
    Juego* j4 = new Juego{"Ordenar", 0, NULL};
    
    j1->siguiente = j2;
    j2->siguiente = j3;
    j3->siguiente = j4;
    
    return j1;
}

void verPerfil(const Personaje* pj) {
    system("cls");

    printCentrado("======= PERFIL DEL JUGADOR =======", 3, 11);

    gotoxy(25, 6);  cout << "Nickname: " << pj->nombre;
    gotoxy(25, 7);  cout << "Nivel:    " << pj->nivel;
    gotoxy(25, 8);  cout << "XP:       " << pj->xp << " / " << pj->xpNecesario;
    gotoxy(25, 9);  cout << "Palabras: " << pj->palabrasAprendidas;

    printCentrado("==================================", 12, 11);
}

void subirNivel(Personaje* pj) {
    while (pj->xp >= pj->xpNecesario) {
        pj->xp -= pj->xpNecesario;
        pj->nivel++;
        pj->xpNecesario = (int)(pj->xpNecesario * 1.5);

        printCentrado("*********", 15);
        printCentrado(" FELICIDADES, HAS SUBIDO! ", 16);
        printCentrado("*********", 17);
    }
}

void mostrarResultados(Personaje* pj, int puntosGanados, int juegoIndex) {
    if (puntosGanados > 0) {
        printCentrado("=== RESULTADOS DEL JUEGO ===", 3, 10);
        printCentrado("Has ganado XP: " + to_string(puntosGanados), 5, 14);

        pj->xp += puntosGanados;

        if (juegoIndex == 1)
            pj->palabrasAprendidas += (puntosGanados / 100);
        else if (juegoIndex == 2)
            pj->palabrasAprendidas += (puntosGanados / 10);
        else if (juegoIndex == 3)
            pj->palabrasAprendidas += (puntosGanados / 30);

        subirNivel(pj);
    }  
}

// ======================= MENU PRINCIPAL ESTILIZADO ===========================

void menuPrincipal(Personaje* pj, Juego* listaJuegos) {
    int opcion = 0;
    int puntos = 0;

    while (opcion != 7) {
        system("cls");

        // Encabezado bonito
        printCentrado("+-------------------------------+", 3, 11);
        printCentrado("       MENU PRINCIPAL RPG       ", 4, 14);
        printCentrado("+-------------------------------+", 5, 11);

        // Perfil resumido
        printCentrado("Jugador: " + pj->nombre + " | Nivel: " + to_string(pj->nivel), 7, 10);

        // Lista de minijuegos
        Juego* actual = listaJuegos;
        int contador = 1;
        int y = 10;

        while (actual != NULL) {
            printCentrado(to_string(contador) + ". " + actual->nombre, y, 15);
            actual = actual->siguiente;
            contador++;
            y++;
        }

        printCentrado(to_string(contador) + ". Ver Perfil", y+1, 11);
        printCentrado(to_string(contador+1) + ". Ver Personajes Guardados", y+2, 13);
        printCentrado(to_string(contador+2) + ". Guardar y Salir", y+3, 12);

        printCentrado("Opcion: ", y+5);
        gotoxy(anchoPantalla/2 + 8, y+5);
        cin >> opcion;

        if (cin.fail()) {
            cin.clear();
            limpiarBufferCin();
            opcion = 0;
        } else {
            limpiarBufferCin();
        }

        switch (opcion) {
            case 1:
                system("cls");
                puntos = iniciarCombate(pj->nombre.c_str());
                mostrarResultados(pj, puntos, 0);
                pausarConsola();
                break;

            case 2:
                system("cls");
                puntos = jugarTraduccionRapida();
                mostrarResultados(pj, puntos, 1);
                pausarConsola();
                break;

            case 3:
                system("cls");
                puntos =  jugarAdivinanza();
                mostrarResultados(pj, puntos, 2);
                pausarConsola();
                break;

            case 4:
                system("cls");
                puntos = jugarOrdenarFrases();
                mostrarResultados(pj, puntos, 3);
                pausarConsola();
                break;

            case 5:
                verPerfil(pj);
                pausarConsola();
                break;
                
            case 6:
                mostrarPersonajesGuardados();
                pausarConsola();
                break;

            case 7:
                guardarPersonaje(pj);
                break;

            default:
                printCentrado("Opcion invalida", 22, 12);
                pausarConsola();
                break;
        }
    }
}

// ======================= MAIN ===========================

int main() {
    srand(time(NULL)); 
    
    Personaje* pj = new Personaje;
    
    system("cls");
    printCentrado("=== SISTEMA DE PERSONAJES ===", 3, 14);
    printCentrado("1. Crear nuevo personaje", 5, 15);
    printCentrado("2. Cargar personaje existente", 6, 15);
    printCentrado("Opcion: ", 8);
    
    int opcionInicio;
    cin >> opcionInicio;
    limpiarBufferCin();
    
    if (opcionInicio == 2) {
        // Cargar personaje existente
        system("cls");
        printCentrado("=== CARGAR PERSONAJE ===", 3, 11);
        printCentrado("Ingresa el nombre del personaje: ", 5);
        string nombreBuscado;
        getline(cin, nombreBuscado);
        
        if (cargarPersonaje(pj, nombreBuscado)) {
            pj->nombre = nombreBuscado;
            printCentrado("Personaje cargado exitosamente!", 7, 10);
            pausarConsola();
        } else {
            printCentrado("Personaje no encontrado. Creando nuevo...", 7, 12);
            pausarConsola();
            
            system("cls");
            printCentrado("Ingresa tu nickname: ", 5);
            getline(cin, pj->nombre);
            
            // Inicializar nuevo personaje
            pj->nivel = 1;
            pj->xp = 0;
            pj->xpNecesario = 100;
            pj->palabrasAprendidas = 0;
            for(int i=0; i<4; i++) pj->progreso[i] = 0;
        }
    } else {
        // Crear nuevo personaje
        system("cls");
        printCentrado("=== NUEVO PERSONAJE ===", 3, 11);
        printCentrado("Ingresa tu nickname: ", 5);
        getline(cin, pj->nombre);
        
        // Validar si el personaje ya existe
        if (personajeExiste(pj->nombre)) {
            printCentrado("�Este personaje ya existe!", 7, 12);
            printCentrado("�Deseas cargarlo? (s/n): ", 8);
            char respuesta;
            cin >> respuesta;
            limpiarBufferCin();
            
            if (respuesta == 's' || respuesta == 'S') {
                if (cargarPersonaje(pj, pj->nombre)) {
                    printCentrado("Personaje cargado exitosamente!", 10, 10);
                } else {
                    printCentrado("Error al cargar el personaje", 10, 12);
                    // Inicializar nuevo personaje
                    pj->nivel = 1;
                    pj->xp = 0;
                    pj->xpNecesario = 100;
                    pj->palabrasAprendidas = 0;
                    for(int i=0; i<4; i++) pj->progreso[i] = 0;
                }
            } else {
                // El usuario quiere crear uno nuevo con mismo nombre (sobrescribir�)
                pj->nivel = 1;
                pj->xp = 0;
                pj->xpNecesario = 100;
                pj->palabrasAprendidas = 0;
                for(int i=0; i<4; i++) pj->progreso[i] = 0;
            }
        } else {
            // Personaje nuevo, inicializar valores
            pj->nivel = 1;
            pj->xp = 0;
            pj->xpNecesario = 100;
            pj->palabrasAprendidas = 0;
            for(int i=0; i<4; i++) pj->progreso[i] = 0;
        }
    }

    Juego* listaJuegos = crearListaJuegos();

    menuPrincipal(pj, listaJuegos);

    delete pj;
    while(listaJuegos != NULL) {
        Juego* temp = listaJuegos;
        listaJuegos = listaJuegos->siguiente;
        delete temp;
    }

    return 0;
}
