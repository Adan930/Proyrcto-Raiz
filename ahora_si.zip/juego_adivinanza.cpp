#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "juego_adivinanza.h"
#define MAX_WORD_LENGTH 50
#define MAX_LINE_LENGTH 256

//------------------------------------------------------
// Funciones internas (no van en el header)
//------------------------------------------------------
static void limpiarPantalla(void) {
#ifdef _WIN32
    system("cls");
#else
    system("clear");
#endif
}

static void mostrarArchivoYEsperar(FILE *file) {
    char linea[MAX_LINE_LENGTH];
    int ch;

    rewind(file);
    printf("Contenido del archivo:\n\n");

    while (fgets(linea, sizeof(linea), file) != NULL) {
        printf("%s", linea);
    }

    printf("\n\nPulsa Enter para continuar...");

    while ((ch = getchar()) != '\n' && ch != EOF) { }
    getchar();

    limpiarPantalla();
    rewind(file);
}

//------------------------------------------------------
// FUNCI�N PRINCIPAL DEL JUEGO (sin par�metros)
//------------------------------------------------------
int jugarAdivinanza(void) {
    FILE *file;
    char word1[MAX_WORD_LENGTH], word2[MAX_WORD_LENGTH];
    char respuesta[MAX_WORD_LENGTH];
    int puntos = 10;
    int totalPairs = 0;

    // --- Aqu� se abre el archivo directamente ---
    file = fopen("C:\\Users\\tinsa\\Downloads\\lenguaje.txt", "r");
    if (file == NULL) {
        printf("Error: no se pudo abrir lenguaje.txt.\n");
        return -1;
    }

    // Contar pares
    while (fscanf(file, "%49s\t%49s", word1, word2) == 2) {
        totalPairs++;
    }
    rewind(file);

    if (totalPairs == 0) {
        printf("El archivo no contiene pares v�lidos.\n");
        fclose(file);
        return -1;
    }

    mostrarArchivoYEsperar(file);
    srand((unsigned int)time(NULL));

    // Bucle principal del juego
    while (1) {
        int randomIndex = rand() % totalPairs;
        int currentIndex = 0;

        rewind(file);
        while (fscanf(file, "%49s\t%49s", word1, word2) == 2) {
            if (currentIndex == randomIndex) break;
            currentIndex++;
        }

        printf("\nAdivina la pareja correcta para: %s\n", word1);
        printf("Ingresa la palabra (o 'salir'): ");
        scanf("%49s", respuesta);

        if (strcmp(respuesta, "salir") == 0) {
            printf("Juego terminado. Puntos finales: %d\n", puntos);
            break;
        }

        if (strcmp(respuesta, word2) == 0) {
            printf("�Correcto!\n");
        } else {
            printf("Incorrecto. La respuesta correcta era: %s\n", word2);
            puntos--;
        }

        printf("Puntos actuales: %d\n", puntos);

        if (puntos <= 0) {
            printf("Has llegado a 0 puntos. Fin del juego.\n");
            break;
        }
    }

    fclose(file);
    return puntos;
}
