#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include "juego_ordenar.h" // Incluimos su propio "anuncio"

// ===================== PALABRAS Y ORACIONES =====================
char* nahuatl_correctas[] = {
    "Nimitztlazohtla" , "Nehuatl nicuica cuicatl" , "Tlakatl motlaloa" ,
    "Piltontli tzajtzia" , "Nimitzitta" , "Tonal mitlalia" ,
    "Atl chkaloki" , "Kokoneh motlaliah" , "Nikuika kuikatl" ,
    "Tlatskanilistli mochipa"
};
char* nahuatl_desordenadas[] = {
    "tla zo mi tz Ni ht", "cu ne atl hu ca nic", "la mo ta tl kl",
    "tz pil ia li ton tz", "ti mi nit tza", "to mi na l tal",
    "at ki chl la o", "ko ne mo ko la h tl", "nik ui ka ka ti",
    "mo li chi ts pa ca"
};
char* xiu_correctas[] = {
    "Gí mãdi" , "Dí nänä" , "Dí pizza gí" , "Bëfi ra hñäki" ,
    "Di rá nthoki" , "Ra mädi hño" , "Ra mädi mähñu" ,
    "Feni ra ngu" , "Ra yohi ra nthö" , "Ra ngú ra mot’e"
};
char* xiu_desordenadas[] = {
    "ma gi dì", "di nä nä", "za gí di piz", "fi ki ra hña",
    "di to nk rá hi", "hño mä ra di", "mäh ra ñu di",
    "ngu ra fe ni", "ra nthö yo ra hi", "ra mó ngú te ra"
};

// ========================== FUNCIÓN PRINCIPAL ==========================

// Función para limpiar el buffer de entrada (el 'Enter' residual)
static void limpiarBufferOrdenar() {
    int c;
    while ((c = getchar()) != '\n' && c != EOF);
}

// 1. Renombramos 'main' a 'jugarOrdenarFrases'
int jugarOrdenarFrases() {
    // 2. Quitamos srand(time(NULL)); 
    //    (ya se llama una vez en el game.cpp principal)

    int eleccion;
    printf("=========================================\n");
    printf("   ELIGE LA LENGUA QUE QUIERES JUGAR\n");
    printf("=========================================\n");
    printf("1. Nahuatl\n");
    printf("2. Xi'u (Otomí)\n");
    printf("Tu opcion: ");
    scanf("%d", &eleccion);
    
    // 3. Arreglamos el buffer que fallaba
    limpiarBufferOrdenar(); 

    char** correctas;
    char** desordenadas;

    if (eleccion == 1) {
        printf("\nJugaremos en NÁHUATL. ¡Tlamachtikan!\n\n");
        correctas = nahuatl_correctas;
        desordenadas = nahuatl_desordenadas;
    } else if (eleccion == 2) {
        printf("\nJugaremos en XI'U (Otomí). ¡Fädi ya jä'i!\n\n");
        correctas = xiu_correctas;
        desordenadas = xiu_desordenadas;
    } else {
        printf("Opcion no valida, mejor vuelve a intentarlo.\n");
        return 0; // Devuelve 0 puntos si la opción es mala
    }

    int puntos = 0;

    for (int i = 0; i < 10; i++) {
        printf("------------------------------------------------\n");
        printf("ORACION DESORDENADA %d:\n", i+1);
        printf("%s\n", desordenadas[i]);
        printf("Acomódala correctamente:\n> ");

        char respuesta[200];
        // 4. Quitamos el getchar() que no funcionaba
        fgets(respuesta, sizeof(respuesta), stdin);
        respuesta[strcspn(respuesta, "\n")] = 0;

        if (strcmp(respuesta, correctas[i]) == 0) {
            printf("¡Bien hecho! +1 punto :)\n");
            puntos++;
        } else {
            printf("Ups... esa no era.\n");
            printf("Correcta: %s\n", correctas[i]);
        }
    }

    printf("\n=====================================\n");
    printf("          FIN DEL JUEGO\n");
    printf("=====================================\n");
    printf("Tu puntuacion final es: %d / 10\n", puntos);

    if (puntos == 10) printf("¡Perfecto! Ya casi eres hablante nativo.\n");
    else if (puntos >= 7) printf("Muy bien, vas por buen camino.\n");
    else printf("Puedes practicar un poquito más, ¡ánimo!\n");

    // 5. Devolvemos los puntos (multiplicados x10) como EXP
    return puntos * 10;
}