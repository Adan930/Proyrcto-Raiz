#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include "juego_adivinanza.h" // Su header

#define MAX_WORD_LENGTH 50

// (Necesitamos esta función de limpiar buffer aquí también)
static void limpiarBufferAdivinanza() {
    int c;
    while ((c = getchar()) != '\n' && c != EOF);
}

// Renombramos 'main'
int jugarAdivinanza() {
    FILE *file;
    char word1[MAX_WORD_LENGTH], word2[MAX_WORD_LENGTH];
    int puntos = 10; 
    int totalPairs = 0;
    char respuesta[MAX_WORD_LENGTH];
    
    file = fopen("lenguaje.txt", "r");
    if (file == NULL) {
        printf("Error al abrir el archivo 'lenguaje.txt'.\n");
        printf("Asegurate de que el archivo este en la misma carpeta que el ejecutable.\n");
        return 0; // Devuelve 0 puntos si falla
    }

    while (fscanf(file, "%s\t%s", word1, word2) == 2) {
        totalPairs++;
    }
    rewind(file); 

    if (totalPairs == 0) {
        printf("El archivo 'lenguaje.txt' no contiene parejas de palabras.\n");
        fclose(file);
        return 0;
    }

    printf("\n=== MINIJUEGO: ADIVINA LA PAREJA ===\n");
    printf("Tienes 10 puntos. Pierdes 1 por cada fallo.\n");

    while (1) {
        int randomIndex = rand() % totalPairs;
        int currentIndex = 0;

        rewind(file);
        while (fscanf(file, "%s\t%s", word1, word2) == 2) {
            if (currentIndex == randomIndex) {
                break;
            }
            currentIndex++;
        }

        printf("\nAdivina la pareja de la palabra: %s\n", word1);
        printf("Ingresa la palabra que crees que corresponde (o escribe 'salir' para terminar): ");
        
        // Usamos scanf para leer una sola palabra
        scanf("%s", respuesta);
        limpiarBufferAdivinanza(); // Limpiamos el buffer (el Enter)

        if (strcmp(respuesta, "salir") == 0) {
            printf("Juego terminado. Puntos finales: %d\n", puntos);
            break;
        }

        if (strcmp(respuesta, word2) == 0) {
            printf("¡Correcto!\n");
        } else {
            printf("Incorrecto. La respuesta correcta era: %s\n", word2);
            puntos -= 1;
        }

        printf("Puntos actuales: %d\n", puntos);
        if (puntos <= 0) {
            printf("Has llegado a 0 puntos. Fin del juego.\n");
            puntos = 0; // Aseguramos que no sea negativo
            break;
        }
    }

    fclose(file);
    // Devolvemos los puntos *solo si son positivos* como "puntaje"
    // Lo multiplico por 10 para que sea más significativo como EXP
    return puntos * 10; 
}
