// Usamos cabeceras de C++ para C (cstdio en lugar de stdio.h)
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include "juego_combate.h" // Incluimos su propio header

// ESTRUCTURAS DEL JUEGO DE COMBAT
typedef struct {
    char palabraEspanol[30];
    char palabraIndigena[30];
    int danio;
} Hechizo;

typedef struct {
    char nombre[30];
    int vidaActual;
    int vidaMax;
    int ataqueBase;
} Enemigo;

typedef struct {
    char nickname[20];
    int vidaActual;
    int vidaMax;
    int experienciaGanada;
} JugadorBatalla;

// --- Funciones de C vs C++ ---
// strcasecmp no es estándar de C++. Esta es una versión simple.
int mi_strcasecmp(const char *s1, const char *s2) {
    while (*s1 && *s2) {
        char c1 = *s1;
        char c2 = *s2;
        if (c1 >= 'A' && c1 <= 'Z') c1 = c1 + ('a' - 'A');
        if (c2 >= 'A' && c2 <= 'Z') c2 = c2 + ('a' - 'A');
        if (c1 != c2) return c1 - c2;
        s1++;
        s2++;
    }
    return *s1 - *s2;
}


void limpiarBufferCombate() {
    int c;
    while ((c = getchar()) != '\n' && c != EOF);
}

void pausarCombate() {
    printf("\nPresione Enter para continuar...");
    // No necesitamos limpiar el buffer ANTES de getchar si usamos C++
    getchar();
}

// LOGICA DEL JUEGO DE COMBATE 

Enemigo crearEnemigo(int nivelDificultad) {
    Enemigo e;
    if (nivelDificultad == 1) {
        strcpy(e.nombre, "Espiritu del Olvido");
        e.vidaMax = 100;
        e.vidaActual = 100;
        e.ataqueBase = 10;
    } else {
        strcpy(e.nombre, "Ignorancia Antigua");
        e.vidaMax = 200;
        e.vidaActual = 200;
        e.ataqueBase = 25;
    }
    return e;
}

void cargarHechizosPrueba(Hechizo lista[], int *cantidad) {
    strcpy(lista[0].palabraEspanol, "Fuego");
    strcpy(lista[0].palabraIndigena, "Tletl"); // Náhuatl
    lista[0].danio = 30;

    strcpy(lista[1].palabraEspanol, "Agua");
    strcpy(lista[1].palabraIndigena, "Atl"); // Náhuatl
    lista[1].danio = 25;

    strcpy(lista[2].palabraEspanol, "Viento");
    strcpy(lista[2].palabraIndigena, "Ehecatl"); // Náhuatl
    lista[2].danio = 20;
    
    *cantidad = 3;
}

// Funcion principal del minijuego 
// Modificada para aceptar const char*
int iniciarCombate(const char *nicknameJugador) {
    JugadorBatalla jugador;
    strcpy(jugador.nickname, nicknameJugador);
    jugador.vidaMax = 100; 
    jugador.vidaActual = jugador.vidaMax;
    jugador.experienciaGanada = 0;

    Enemigo enemigo = crearEnemigo(1); 
    
    Hechizo grimoire[10];
    int totalHechizos = 0;
    cargarHechizosPrueba(grimoire, &totalHechizos);

    int turno = 1;
    int opcionHechizo;
    char respuestaUsuario[30];

    printf("\n=== INICIANDO COMBATE ===\n");
    printf("�Un %s salvaje ha aparecido!\n", enemigo.nombre);
    pausarCombate();

    // Bucle principal de la batalla
    while (jugador.vidaActual > 0 && enemigo.vidaActual > 0) {
        printf("\n--- TURNO %d ---\n", turno);
        printf("[%s] HP: %d/%d\n", jugador.nickname, jugador.vidaActual, jugador.vidaMax);
        printf("[%s] HP: %d/%d\n", enemigo.nombre, enemigo.vidaActual, enemigo.vidaMax);
        printf("----------------\n");

        printf("�Es tu turno! Elige un hechizo (palabra a traducir):\n");
        for(int i = 0; i < totalHechizos; i++) {
            printf("%d. %s (Dano potencial: %d)\n", i+1, grimoire[i].palabraEspanol, grimoire[i].danio);
        }
        printf("Opcion: ");
        
        // Usar scanf y limpiar buffer es delicado,
        // pero lo mantenemos por consistencia con tu código
        if (scanf("%d", &opcionHechizo) != 1) {
             opcionHechizo = 0; // Opción inválida si no es número
        }
        limpiarBufferCombate(); // Limpia el Enter o letras

        if (opcionHechizo < 1 || opcionHechizo > totalHechizos) {
            printf("�Te tropezaste! Perdiste tu turno por elegir una opcion invalida.\n");
        } else {
            int indice = opcionHechizo - 1;
            printf("\nPara lanzar el hechizo de '%s', escribe su traduccion en Nahuatl:\n> ", grimoire[indice].palabraEspanol);
            fgets(respuestaUsuario, 30, stdin);
            respuestaUsuario[strcspn(respuestaUsuario, "\n")] = 0; // Eliminar salto de línea

            // Usamos nuestra función compatible
            if (mi_strcasecmp(respuestaUsuario, grimoire[indice].palabraIndigena) == 0) {
                printf("\n�CORRECTO! �Lanzaste %s!\n", grimoire[indice].palabraIndigena);
                printf("Causas %d puntos de da�o a %s.\n", grimoire[indice].danio, enemigo.nombre);
                enemigo.vidaActual -= grimoire[indice].danio;
            } else {
                printf("\n�FALLASTE! La palabra correcta era '%s'.\n", grimoire[indice].palabraIndigena);
                printf("El hechizo explota en tu cara, recibes 5 de daño.\n");
                jugador.vidaActual -= 5;
            }
        }
        
        if (enemigo.vidaActual <= 0) break;
        pausarCombate();

        printf("\n--- Turno del Enemigo ---\n");
        printf("%s te ataca y causa %d de da�o!\n", enemigo.nombre, enemigo.ataqueBase);
        jugador.vidaActual -= enemigo.ataqueBase;
        
        if (jugador.vidaActual > 0) {
             pausarCombate();
        }

        turno++;
    }

    // Fin del combate
    system("cls || clear");
    if (jugador.vidaActual > 0) {
        printf("\n�VICTORIA!\n");
        printf("Has derrotado a %s.\n", enemigo.nombre);
        jugador.experienciaGanada = 50; // Valor de ejemplo
        printf("Ganas %d puntos de experiencia.\n", jugador.experienciaGanada);
        return jugador.experienciaGanada; // Retorna EXP
    } else {
        printf("\nDERROTA...\n");
        printf("%s te ha vencido.\n", enemigo.nombre);
        return 0; // Retorna 0 EXP
    }
}
