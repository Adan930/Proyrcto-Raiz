#ifndef JUEGO_TRADUCCION_H
#define JUEGO_TRADUCCION_H

// Esto es crucial para enlazar C y C++
#ifdef __cplusplus
extern "C" {
#endif

// Prototipo. Devuelve los puntos totales.
int jugarTraduccionRapida();

#ifdef __cplusplus
}
#endif

#endif // JUEGO_TRADUCCION_H