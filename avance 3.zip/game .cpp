#include "game.h"
#include <iostream>
#include <string>
#include <limits> // Para limpiar el buffer de cin

// Incluimos los "anuncios" (headers) de nuestros minijuegos en C
#include "juego_combate.h"
#include "juego_traduccion.h"
#include "juego_adivinanza.h"
#include "juego_ordenar.h" // Header modificado para juego_ordenar

using namespace std;

// --- Implementacion de funciones de game.h ---

void limpiarBufferCin() {
    cin.ignore(numeric_limits<streamsize>::max(), '\n');
}

void pausarConsola() {
    cout << "\nPresiona Enter para continuar...";
    // Limpia cualquier 'Enter' residual antes de esperar uno nuevo
    limpiarBufferCin();
    getchar(); // Espera un Enter
}

Juego* crearListaJuegos() {
    // Por ahora, una lista simple. Esto podria cargarse de un archivo.
    Juego* j1 = new Juego{"Combate", 0, NULL};
    Juego* j2 = new Juego{"Traduccion Rapida", 0, NULL};
    Juego* j3 = new Juego{"Adivinanza", 0, NULL};
    Juego* j4 = new Juego{"Ordenar", 0, NULL}; // Juego modificado
    
    j1->siguiente = j2;
    j2->siguiente = j3;
    j3->siguiente = j4;
    
    return j1;
}

void verPerfil(const Personaje* pj) {
    system("cls || clear"); // Limpia la pantalla (Windows || Linux/Mac)
    cout << "=== PERFIL DEL JUGADOR ===" << endl;
    cout << "Nickname: " << pj->nombre << endl;
    cout << "Nivel:    " << pj->nivel << endl;
    cout << "XP:       " << pj->xp << " / " << pj->xpNecesario << endl;
    cout << "Palabras: " << pj->palabrasAprendidas << endl;
    cout << "--------------------------" << endl;
}

void subirNivel(Personaje* pj) {
    // Bucle por si sube m�ltiples niveles
    while (pj->xp >= pj->xpNecesario) {
        pj->xp -= pj->xpNecesario;
        pj->nivel++;
        pj->xpNecesario = (int)(pj->xpNecesario * 1.5); // Incremento de XP
        
        cout << "\n*************************" << endl;
        cout << "�FELICIDADES, " << pj->nombre << "!" << endl;
        cout << "�Has subido al Nivel " << pj->nivel << "!" << endl;
        cout << "Proximo nivel en " << pj->xpNecesario << " XP." << endl;
        cout << "*************************" << endl;
    }
}

void mostrarResultados(Personaje* pj, int puntosGanados, int juegoIndex) {
    if (puntosGanados > 0) {
        cout << "\n[Resumen] Has ganado " << puntosGanados << " puntos de experiencia." << endl;
        pj->xp += puntosGanados;
        
        // Actualizamos el progreso de ese juego (ej. palabras aprendidas)
        // juegoIndex 0 = Combate, 1 = Traduccion, 2 = Adivinanza, 3 = Ordenar
        if (juegoIndex == 1) { // Traducci�n R�pida
             // Asumimos que los puntos son aprox. palabras
            pj->palabrasAprendidas += (puntosGanados / 100); 
        } else if (juegoIndex == 2) { // Adivinanza
            pj->palabrasAprendidas += (puntosGanados / 10);
        } else if (juegoIndex == 3) { // Ordenar
            pj->palabrasAprendidas += (puntosGanados / 30); // Ajuste para juego de ordenar
        }
        
        // Verificamos si sube de nivel
        subirNivel(pj);
    } else {
        cout << "\n[Resumen] No has ganado experiencia esta vez. �Sigue intentando!" << endl;
    }
}

void guardarPersonaje(const Personaje* pj) {
    // L�gica para guardar en un archivo (ej. "perfil.dat")
    // Por ahora, solo un mensaje:
    cout << "Perfil guardado (simulado)." << endl;
}

void menuPrincipal(Personaje* pj, Juego* listaJuegos) {
    int opcion = 0;
    int puntos = 0;

    while (opcion != 6) { // Cambiado a 6 por el nuevo juego
        system("cls || clear");
        verPerfil(pj);
        
        cout << "\n=== MENU PRINCIPAL ===" << endl;
        cout << "Elige un minijuego:" << endl;
        
        // Navegar por la lista de juegos din�micamente
        Juego* actual = listaJuegos;
        int contador = 1;
        while (actual != NULL) {
            cout << contador << ". " << actual->nombre << endl;
            actual = actual->siguiente;
            contador++;
        }
        
        cout << contador << ". Ver Perfil (Actualizar)" << endl;
        cout << contador + 1 << ". Guardar y Salir" << endl;
        cout << "Opcion: ";
        
        cin >> opcion;
        if (cin.fail()) {
            cin.clear();
            limpiarBufferCin();
            opcion = 0;
        } else {
            limpiarBufferCin(); // Limpia el Enter
        }

        switch (opcion) {
            case 1:
                system("cls || clear");
                puntos = iniciarCombate(pj->nombre.c_str());
                mostrarResultados(pj, puntos, 0);
                pausarConsola();
                break;
            case 2:
                system("cls || clear");
                puntos = jugarTraduccionRapida();
                mostrarResultados(pj, puntos, 1);
                pausarConsola();
                break;
            case 3:
                system("cls || clear");
                puntos = jugarAdivinanza(;
                mostrarResultados(pj, puntos, 2);
                pausarConsola();
                break;
            case 4: // Caso para el Juego Ordenar
                system("cls || clear");
                puntos = jugarOrdenar();
                mostrarResultados(pj, puntos, 3);
                pausarConsola();
                break;
            case 5: // Ver Perfil
                // Solo para refrescar el perfil
                break;
            case 6: // Guardar y Salir
                guardarPersonaje(pj);
                cout << "�Gracias por jugar! Adios." << endl;
                break;
            default:
                cout << "Opcion invalida. Intenta de nuevo." << endl;
                pausarConsola();
                break;
        }
    }
}

// --- PUNTO DE ENTRADA PRINCIPAL ---

int main() {
    // Inicializa el generador de n�meros aleatorios
    srand(time(NULL)); 
    
    // Carga o crea el personaje
    Personaje* pj = new Personaje;
    cout << "Bienvenido al juego. Ingresa tu nickname: ";
    getline(cin, pj->nombre);
    
    pj->nivel = 1;
    pj->xp = 0;
    pj->xpNecesario = 100;
    pj->palabrasAprendidas = 0;
    for(int i=0; i<4; i++) pj->progreso[i] = 0;

    // Carga la lista de juegos
    Juego* listaJuegos = crearListaJuegos();

    // Inicia el bucle principal
    menuPrincipal(pj, listaJuegos);

    // Liberar memoria (buena pr�ctica)
    delete pj;
    while(listaJuegos != NULL) {
        Juego* temp = listaJuegos;
        listaJuegos = listaJuegos->siguiente;
        delete temp;
    }

    return 0;
}
