#ifndef JUEGO_ADIVINANZA_H
#define JUEGO_ADIVINANZA_H

// Esto es crucial para enlazar C y C++
#ifdef __cplusplus
extern "C" {
#endif

// Prototipo. Devuelve los puntos finales.
int jugarMemorama();

#ifdef __cplusplus
}
#endif

#endif // JUEGO_ADIVINANZA_H
