#include <iostream>  // Necesario para cin/cout
#include <string>
#include <windows.h>
#include <cstdio>    // Mantenemos para sprintf si hace falta
#include "juego_combate.h"

using namespace std; // Para no escribir std:: a cada rato

// --- FUNCIONES VISUALES (Adaptadas a C++) ---
static void gotoxy(int x, int y) {
    COORD coord; coord.X = x; coord.Y = y;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
}

static void setColor(int color) {
    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), color);
}

static void centrar(string txt, int y, int color) {
    CONSOLE_SCREEN_BUFFER_INFO csbi;
    GetConsoleScreenBufferInfo(GetStdHandle(STD_OUTPUT_HANDLE), &csbi);
    int ancho = csbi.srWindow.Right - csbi.srWindow.Left + 1;
    // Calculo seguro para evitar posiciones negativas
    int x = (ancho - (int)txt.length()) / 2;
    if (x < 0) x = 0;
    
    setColor(color);
    gotoxy(x, y); 
    cout << txt; // Usamos cout en lugar de printf
    setColor(7); 
}

// --- ESTRUCTURAS ---
struct Hechizo { string esp; string ind; int danio; };
struct Enemigo { string nombre; int vida; int maxVida; int ataque; };
struct JugadorBatalla { string nick; int vida; int maxVida; };

// Helper para comparar strings sin importar mayusculas
static bool esIgual(string a, string b) {
    if (a.length() != b.length()) return false;
    for (size_t i = 0; i < a.length(); i++) {
        if (tolower(a[i]) != tolower(b[i])) return false;
    }
    return true;
}

// --- LOGICA PRINCIPAL ---
int iniciarCombate(const char *nicknameJugador) {
    int dificultad = 1;

    // --- CORRECCI�N DEL MEN� ---
    system("cls");
    centrar("=== COMBATE NAHUATL ===", 3, 11);
    centrar("1. Nivel Basico (Espiritu Debil)", 6, 10);
    centrar("2. Nivel Avanzado (Demonio Antiguo)", 7, 12);
    centrar("Elige dificultad: ", 9, 7);
    
    // Usamos cin para evitar conflictos con el buffer del main
    gotoxy(45, 9); // Ponemos el cursor al lado del texto
    if (!(cin >> dificultad)) {
        // Si el usuario escribe letras, limpiamos el error
        cin.clear();
        cin.ignore(1000, '\n');
        dificultad = 1; 
    }
    cin.ignore(1000, '\n'); // Limpiar el Enter sobrante

    // Configurar Enemigo
    Enemigo enemigo;
    if (dificultad == 2) {
        enemigo = {"Tlacatecolotl (Demonio)", 150, 150, 25};
    } else {
        enemigo = {"Espiritu del Bosque", 80, 80, 10};
    }

    JugadorBatalla jugador;
    jugador.nick = string(nicknameJugador);
    jugador.maxVida = 100;
    jugador.vida = 100;

    Hechizo grimoire[3] = {
        {"Fuego", "Tletl", 35},
        {"Agua", "Atl", 25},
        {"Viento", "Ehecatl", 20}
    };

    // 2. BUCLE DE PELEA
    while (jugador.vida > 0 && enemigo.vida > 0) {
        system("cls");
        
        // HUD
        setColor(11);
        cout << "\n  " << jugador.nick << " (HP: " << jugador.vida << "/" << jugador.maxVida << ")";
        cout << "  VS  " << enemigo.nombre << " (HP: " << enemigo.vida << "/" << enemigo.maxVida << ")\n";
        setColor(7);
        cout << "  --------------------------------------------------\n\n";

        // Menu Hechizos
        cout << "  TU TURNO - Elige un hechizo:\n";
        for(int i=0; i<3; i++) {
            cout << "  " << i+1 << ". " << grimoire[i].esp << " (Danio: " << grimoire[i].danio << ")\n";
        }
        cout << "\n  Opcion > ";
        
        int op;
        if (!(cin >> op)) {
            cin.clear();
            cin.ignore(1000, '\n');
            op = 0;
        }
        cin.ignore(1000, '\n'); // Limpiar buffer

        if (op < 1 || op > 3) {
            cout << "\n  Perdiste el turno por distraccion...\n";
        } else {
            int idx = op - 1;
            cout << "\n  Escribe '" << grimoire[idx].esp << "' en Nahuatl: ";
            
            string respuesta;
            getline(cin, respuesta); // getline es mas seguro que fgets

            if (esIgual(respuesta, grimoire[idx].ind)) {
                setColor(10); // Verde
                cout << "\n  CORRECTO! " << grimoire[idx].ind << " impacta al enemigo!\n";
                enemigo.vida -= grimoire[idx].danio;
            } else {
                setColor(12); // Rojo
                cout << "\n  FALLASTE. La palabra era '" << grimoire[idx].ind << "'.\n";
            }
        }
        setColor(7);

        if (enemigo.vida <= 0) break; // Ganaste

        Sleep(1000);
        // Turno del Enemigo
        cout << "\n  --- Turno de " << enemigo.nombre << " ---\n";
        cout << "  Te ataca y causa " << enemigo.ataque << " de danio!\n";
        jugador.vida -= enemigo.ataque;
        
        cout << "\n  Presiona Enter...";
        cin.get(); // Pausa estilo C++
    }

    // 3. RESULTADOS
    system("cls");
    if (enemigo.vida <= 0) {
        centrar("VICTORIA MAGISTRAL", 10, 10);
        centrar("Derrotaste a " + enemigo.nombre, 12, 15);
        Sleep(2000);
        return (dificultad == 2) ? 100 : 50; 
    } else {
        setColor(12);
        centrar("DERROTA...", 10, 12);
        centrar("Te has quedado sin puntos de vida.", 12, 14);
        Sleep(2000);
        return 0;
    }
}
