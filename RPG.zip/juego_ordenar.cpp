#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <windows.h>
#include "juego_ordenar.h"

// ===== COLORES ANSI =====
#define RESET   "\033[0m"
#define ROJO    "\033[31m"
#define VERDE   "\033[32m"
#define AMARILLO "\033[33m"
#define CYAN    "\033[36m"
#define MAGENTA "\033[35m"
#define BLANCO  "\033[37m"

// ===== ENABLE ANSI COLORS EN WINDOWS =====
void habilitarANSI() {
    HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
    DWORD modo = 0;
    GetConsoleMode(h, &modo);
    // Activa el modo para procesar c�digos de color ANSI
    SetConsoleMode(h, modo | 0x0004); 
}

// ===== GOTOXY REAL =====
static void gotoxy(int x, int y) {
    COORD c;
    c.X = x;
    c.Y = y;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), c);
}

// ===== LIMPIAR BUFFER (ROBUSTO) =====
static void limpiarBufferOrdenar() {
    int c;
    while ((c = getchar()) != '\n' && c != EOF);
}

// ===================== ARRAYS CORREGIDOS (const char*) =====================
// NOTA: En C++, los strings literales deben ser const char*

const char* nahuatl_correctas[] = {
    "Nimitztlazohtla" , "Nehuatl nicuica cuicatl" , "Tlakatl motlaloa" ,
    "Piltontli tzajtzia" , "Nimitzitta" , "Tonal mitlalia" ,
    "Atl chkaloki" , "Kokoneh motlaliah" , "Nikuika kuikatl" ,
    "Tlatskanilistli mochipa"
};

const char* nahuatl_desordenadas[] = {
    "tla zo mi tz Ni ht", "cu ne atl hu ca nic", "la mo ta tl kl",
    "tz pil ia li ton tz", "ti mi nit tza", "to mi na l tal",
    "at ki chl la o", "ko ne mo ko la h tl", "nik ui ka ka ti",
    "mo li chi ts pa ca"
};

// Palabras avanzadas
const char* nahuatl_avanzadas_correctas[] = {
    "Nimitztlazohtla huehca", "Nehuatl nicuica cuicatl tlahtolli",
    "Tlakatl motlaloa ichan", "Piltontli tzajtzia chicahuac",
    "Nimitzitta nochi", "Tonal mitlalia yolotl",
    "Atl chkaloki ipan", "Kokoneh motlaliah tlatskanilistli",
    "Nikuika kuikatl hueyi", "Tlatskanilistli mochipa tlakatl"
};

const char* nahuatl_avanzadas_desordenadas[] = {
    "hu mi tz tl ah co he la tza", "cu tl tla ca tol ua ic ni ci hu ne",
    "ich ta cha mo tl an ka tl lo", "chi li ton tz tz ac pi li ca hu",
    "no it nitz mi chi ta", "yo mi na tal l ni to lo y tl",
    "ip at pan la ch o kl", "mo ko li ne tl ko h na la tsa h",
    "ka i ya ku ui ki we ta", "mo tl pa chi ts li ca tl sk ta na"
};

// ========================================================================================
//                                JUGAR ORDENAR FRASES
// ========================================================================================
int jugarOrdenarFrases() {

    habilitarANSI(); // Activa colores brillantes

    int dificultad = 0;
    int intentos = 3;
    int tiempoLimite = 15; // (Variable visual, no implementada en l�gica real por simplicidad)
    int usarAvanzado = 0;

    system("cls");

    // ===================== PANTALLA DE DIFICULTAD =====================
    gotoxy(20, 3); printf(MAGENTA "===============================================" RESET);
    gotoxy(20, 4); printf(CYAN    "            SELECCIONA LA DIFICULTAD            " RESET);
    gotoxy(20, 5); printf(MAGENTA "===============================================" RESET);

    gotoxy(25, 8);  printf(VERDE  "1) BASICO" RESET);
    gotoxy(25, 9);  printf(BLANCO "   - Pistas disponibles" RESET);
    gotoxy(25,10);  printf(BLANCO "   - Frases cortas" RESET);

    gotoxy(25,13);  printf(ROJO   "2) AVANZADO" RESET);
    gotoxy(25,14);  printf(BLANCO "   - Frases largas" RESET);
    gotoxy(25,15);  printf(BLANCO "   - Sin pistas visuales" RESET);

    gotoxy(25,18);
    printf(AMARILLO "Selecciona opcion: " RESET);
    
    // Lectura protegida
    if (scanf("%d", &dificultad) != 1) {
        dificultad = 1; // Default por si fallan
    }
    limpiarBufferOrdenar(); // CRUCIAL: Consumir el Enter

    if (dificultad == 2) {
        usarAvanzado = 1;
        tiempoLimite = 10;
    }

    // ================================================================
    // LENGUA
    // ================================================================
    int eleccion = 0;
    system("cls");

    gotoxy(20, 3); printf(MAGENTA "===============================================" RESET);
    gotoxy(20, 4); printf(CYAN    "            ELIGE LA LENGUA A JUGAR             " RESET);
    gotoxy(20, 5); printf(MAGENTA "===============================================" RESET);

    gotoxy(30, 8); printf("1. Nahuatl");
    gotoxy(30, 9); printf("2. Xi'u (Otomi) [En construccion]");

    gotoxy(30, 12);
    printf("Tu opcion: ");

    if (scanf("%d", &eleccion) != 1) {
        eleccion = 1;
    }
    limpiarBufferOrdenar();

    // Punteros a constantes (const char**)
    const char **correctas;
    const char **desordenadas;

    // Por defecto cargamos Nahuatl (simple o avanzado)
    if (usarAvanzado == 0) {
        correctas = nahuatl_correctas;
        desordenadas = nahuatl_desordenadas;
    } else {
        correctas = nahuatl_avanzadas_correctas;
        desordenadas = nahuatl_avanzadas_desordenadas;
    }
    // NOTA: Si eligieran Otom�, aqu� deber�as a�adir otro IF para cambiar los punteros

    system("cls");

    int puntos = 0;

    // ===================== BUCLE DEL JUEGO =====================
    // Solo jugamos 5 rondas para no hacerlo eterno, o hasta acabar intentos
    for (int i = 0; i < 5 && intentos > 0; i++) {

        gotoxy(10, 3); printf(CYAN "Intentos restantes: %d" RESET, intentos);
        gotoxy(10, 5); printf(MAGENTA "ORACION DESORDENADA %d" RESET, i + 1);

        gotoxy(10, 7); printf(AMARILLO "%s" RESET, desordenadas[i]);

        // Mostrar pista solo en b�sico
        if (dificultad == 1) {
            gotoxy(10, 9); 
            printf(VERDE "Pista: empieza con '%c'\n" RESET, correctas[i][0]);
        }

        gotoxy(10, 11);
        printf("Acomodala correctamente:");

        gotoxy(10, 12);
        printf("> ");

        char respuesta[200];
        // fgets lee hasta el enter
        if (fgets(respuesta, sizeof(respuesta), stdin) != NULL) {
            // Eliminar salto de l�nea del final
            respuesta[strcspn(respuesta, "\n")] = 0;
        }

        // Comparar
        if (strcmp(respuesta, correctas[i]) == 0) {
            gotoxy(10, 14);
            printf(VERDE "�Correcto! +1 punto\n" RESET);
            puntos++;
        } else {
            gotoxy(10, 14);
            printf(ROJO "Incorrecto.\n" RESET);
            gotoxy(10, 15);
            printf("Correcta: %s\n", correctas[i]);
            intentos--;
        }

        Sleep(2000); // Esperar 2 segundos para leer
        system("cls");
    }

    // ===================== RESULTADOS =====================
    // Guardar log local
    FILE *f = fopen("resultados_ordenar.txt", "a");
    if (f) {
        fprintf(f, "Puntos: %d  |  Dificultad: %s  |  Intentos restantes: %d\n",
            puntos,
            (usarAvanzado ? "Avanzado" : "Basico"),
            intentos
        );
        fclose(f);
    }

    gotoxy(20, 8);
    if (intentos > 0) printf(VERDE "�JUEGO TERMINADO CON EXITO!\n" RESET);
    else printf(ROJO "TE HAS QUEDADO SIN INTENTOS\n" RESET);

    gotoxy(20, 10);
    printf(MAGENTA "Puntuacion final: %d exp\n" RESET, puntos * 10);
    
    Sleep(2000);

    // Retornamos puntos multiplicados por 10 para la XP global
    return puntos * 10;
}
