#ifndef JUEGO_ADIVINANZA_H
#define JUEGO_ADIVINANZA_H

int jugarAdivinanza(void);

#endif

