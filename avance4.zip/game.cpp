#include "game.h"
#include <iostream>
#include <string>
#include <limits> 
#include <windows.h> // ? Para gotoxy y colores

#include "juego_combate.h"
#include "juego_traduccion.h"
#include "juego_adivinanza.h"
#include "juego_ordenar.h"

using namespace std;

// ======================= GOTOXY Y COLORES ===========================
void gotoxy(int x, int y) {
    COORD c;
    c.X = x;
    c.Y = y;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), c);
}

void setColor(int color) {
    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), color);
}

int anchoPantalla = 80;

void printCentrado(const string& txt, int y, int color = 15) {
    int x = (anchoPantalla - txt.size()) / 2;
    setColor(color);
    gotoxy(x, y);
    cout << txt;
    setColor(15);
}

// ======================= FUNCIONES ORIGINALES ===========================

void limpiarBufferCin() {
    cin.ignore(numeric_limits<streamsize>::max(), '\n');
}

void pausarConsola() {
    cout << "\nPresiona Enter para continuar...";
    limpiarBufferCin();
    getchar();
}

Juego* crearListaJuegos() {
    Juego* j1 = new Juego{"Combate", 0, NULL};
    Juego* j2 = new Juego{"Traduccion Rapida", 0, NULL};
    Juego* j3 = new Juego{"Adivinanza", 0, NULL};
    Juego* j4 = new Juego{"Ordenar", 0, NULL};
    
    j1->siguiente = j2;
    j2->siguiente = j3;
    j3->siguiente = j4;
    
    return j1;
}

void verPerfil(const Personaje* pj) {
    system("cls");

    printCentrado("======= PERFIL DEL JUGADOR =======", 3, 11);

    gotoxy(25, 6);  cout << "Nickname: " << pj->nombre;
    gotoxy(25, 7);  cout << "Nivel:    " << pj->nivel;
    gotoxy(25, 8);  cout << "XP:       " << pj->xp << " / " << pj->xpNecesario;
    gotoxy(25, 9);  cout << "Palabras: " << pj->palabrasAprendidas;

    printCentrado("==================================", 12, 11);
}

void subirNivel(Personaje* pj) {
    while (pj->xp >= pj->xpNecesario) {
        pj->xp -= pj->xpNecesario;
        pj->nivel++;
        pj->xpNecesario = (int)(pj->xpNecesario * 1.5);

        printCentrado("*********", 15);
        printCentrado(" FELICIDADES, HAS SUBIDO! ", 16);
        printCentrado("*********", 17);
    }
}

void mostrarResultados(Personaje* pj, int puntosGanados, int juegoIndex) {
    if (puntosGanados > 0) {
        printCentrado("=== RESULTADOS DEL JUEGO ===", 3, 10);
        printCentrado("Has ganado XP: " + to_string(puntosGanados), 5, 14);

        pj->xp += puntosGanados;

        if (juegoIndex == 1)
            pj->palabrasAprendidas += (puntosGanados / 100);
        else if (juegoIndex == 2)
            pj->palabrasAprendidas += (puntosGanados / 10);
        else if (juegoIndex == 3)
            pj->palabrasAprendidas += (puntosGanados / 30);

        subirNivel(pj);
    }  
}

void guardarPersonaje(const Personaje* pj) {
    printCentrado("Perfil guardado (simulado).", 20, 10);
}

// ======================= MENU PRINCIPAL ESTILIZADO ===========================

void menuPrincipal(Personaje* pj, Juego* listaJuegos) {
    int opcion = 0;
    int puntos = 0;

    while (opcion != 6) {
        system("cls");

        // Encabezado bonito
        printCentrado("+-------------------------------+", 3, 11);
        printCentrado("       MENU PRINCIPAL RPG       ", 4, 14);
        printCentrado("+-------------------------------+", 5, 11);

        // Perfil resumido
        printCentrado("Jugador: " + pj->nombre + " | Nivel: " + to_string(pj->nivel), 7, 10);

        // Lista de minijuegos
        Juego* actual = listaJuegos;
        int contador = 1;
        int y = 10;

        while (actual != NULL) {
            printCentrado(to_string(contador) + ". " + actual->nombre, y, 15);
            actual = actual->siguiente;
            contador++;
            y++;
        }

        printCentrado(to_string(contador) + ". Ver Perfil", y+1, 11);
        printCentrado(to_string(contador+1) + ". Guardar y Salir", y+2, 12);

        printCentrado("Opcion: ", y+4);
        gotoxy(anchoPantalla/2 + 8, y+4);
        cin >> opcion;

        if (cin.fail()) {
            cin.clear();
            limpiarBufferCin();
            opcion = 0;
        } else {
            limpiarBufferCin();
        }

        switch (opcion) {
            case 1:
                system("cls");
                puntos = iniciarCombate(pj->nombre.c_str());
                mostrarResultados(pj, puntos, 0);
                pausarConsola();
                break;

            case 2:
                system("cls");
                puntos = jugarTraduccionRapida();
                mostrarResultados(pj, puntos, 1);
                pausarConsola();
                break;

            case 3:
                system("cls");
                puntos =  jugarAdivinanza();
                mostrarResultados(pj, puntos, 2);
                pausarConsola();
                break;

            case 4:
                system("cls");
                puntos = jugarOrdenarFrases();
                mostrarResultados(pj, puntos, 3);
                pausarConsola();
                break;

            case 5:
                verPerfil(pj);
                pausarConsola();
                break;

            case 6:
                guardarPersonaje(pj);
                break;

            default:
                printCentrado("Opcion invalida", 22, 12);
                pausarConsola();
                break;
        }
    }
}

// ======================= MAIN ===========================

int main() {
    srand(time(NULL)); 
    
    Personaje* pj = new Personaje;
    cout << "Bienvenido al juego. Ingresa tu nickname: ";
    getline(cin, pj->nombre);
    
    pj->nivel = 1;
    pj->xp = 0;
    pj->xpNecesario = 100;
    pj->palabrasAprendidas = 0;
    for(int i=0; i<4; i++) pj->progreso[i] = 0;

    Juego* listaJuegos = crearListaJuegos();

    menuPrincipal(pj, listaJuegos);

    delete pj;
    while(listaJuegos != NULL) {
        Juego* temp = listaJuegos;
        listaJuegos = listaJuegos->siguiente;
        delete temp;
    }

    return 0;
}
