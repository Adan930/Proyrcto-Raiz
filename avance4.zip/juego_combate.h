#ifndef JUEGO_COMBATE_H
#define JUEGO_COMBATE_H

// Esto es crucial para enlazar C y C++
#ifdef __cplusplus
extern "C" {
#endif

// Prototipo de la función principal del combate
// Devuelve la EXP ganada
// Acepta const char* para ser compatible con string::c_str() de C++
int iniciarCombate(const char *nicknameJugador);

#ifdef __cplusplus
}
#endif

#endif // JUEGO_COMBATE_H